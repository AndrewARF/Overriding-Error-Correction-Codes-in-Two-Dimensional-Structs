public class Decoder {
	private static int outerAddTab[] = {-1,-1,-1, 0, -1, 1, 2, 3}; 
	private static int innerAddTab[] = {-1,-1,-1, 1, -1, 2, 3, 0};
	private static final int[][][] doubleErrorMap = {
			//                              EArI
			//     0         1         2         3         4         5         6         7       
			{{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}},  // 0
			{{-1, -1}, {-1, -1}, {-1, -1}, {2,   3}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}},  // 1
/*E*/		{{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {1,   3}, {-1, -1}, {-1, -1}},  // 2
/*A*/		{{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {1,   2}, {-1, -1}},  // 3
/*r*/		{{-1, -1}, {0,   3}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}},  // 4
/*O*/		{{-1, -1}, {-1, -1}, {0,  2},  {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}},  // 5
			{{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {0,   1}, {-1, -1}, {-1, -1}, {-1, -1}},  // 6
			{{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}}   // 7
	};	
									
	public static boolean decoding(CodeStructWithErrror ecc) {
		boolean detectouErro = (ecc.sPo != 0 || ecc.sPi != 0 || ecc.EArO != 0 || ecc.EArI != 0) ? true : false;
		
		if(ecc.EArO == 0 || ecc.EArI == 0)
			return detectouErro;

		if(ecc.SErO) {
			int add = outerAddTab[ecc.EArO];
			if(add!=-1)
				ecc.D[add] = ecc.D[add]==0 ? 1 : 0; // Flip a bit
			ecc.recomputeControlVariables();
			return detectouErro;
		}
		if(ecc.SErI) {
			int add = innerAddTab[ecc.EArI];
			if(add!=-1)
				ecc.D[add] = ecc.D[add]==0 ? 1 : 0; // Flip a bit
			ecc.recomputeControlVariables();
			return detectouErro;
		}
		if(ecc.DErO && ecc.DErI) {
			int[] errorPositions = doubleErrorMap[ecc.EArO][ecc.EArI];
			int addA = errorPositions[0];
			int addB = errorPositions[1];

			if(addA != -1 && addB != -1) {
				ecc.D[addA] = ecc.D[addA]==0 ? 1 : 0; // Flip a bit
				ecc.D[addB] = ecc.D[addB]==0 ? 1 : 0; // Flip a bit
			}
			ecc.recomputeControlVariables();
			return detectouErro;
		}
		return detectouErro;
    }
}