public class CodeStructWithErrror extends CodeStruct
{
	public int recCo[] = new int[3];	// Array storing the computation of the Outer Hamming in the decoding process 
	public int recCi[] = new int[3];	// Array storing the computation of the Inner Hamming in the decoding process 
	public int recPo, recPi;			// Bits storing the Outer and Inner parities computed in the decoding process 
	
	public int sCo[] = new int[3];		// Array of Outer Hamming syndromes
	public int sCi[] = new int[3];		// Array of Inner Hamming syndromes
	public int sPo, sPi;				// Outer and Inner parity syndromes
	public int sCoq, sCiq;				// Bits enclosing the OR of all bits of the Outer and Inner syndrome arrays

	public int EArO, EArI;				// Outer and Inner error addresses
	public boolean DErO, SErO;			// Flags of double and single error on Outer ECC
	public boolean DErI, SErI;			// Flags of double and single error on Inner ECC
	public CodeStructWithErrror(CodeStruct initialCodeStruct, int errorPattern[]) throws Exception { // Constructor for creating an instance of the code with an error pattern inserted
		super(initialCodeStruct.D);
		setErrorPattern(errorPattern);
		recomputeControlVariables();
	}
	public void recomputeControlVariables() { // Method that recompute all control variables after correcting an error
		recomputeCheckBitsAndParity();
		computeSyndromes();
		computeErrorAddress();
		computeSE_DE();
	}
	public void recomputeCheckBitsAndParity() { // Recompute Hamming and parity of Outer and Inner ECCs
		encodeOuterHamming(recCo);
		recPo = encodeHammingParity(Co);
		encodeInnerHamming(recCi);
		recPi = encodeHammingParity(Ci);
	}
	public void computeSyndromes() { // Compute all syndromes
		for(int k=0; k<sCi.length; k++)
			sCi[k] = Ci[k] == recCi[k] ? 0 : 1;
		sPi = Pi == recPi ? 0 : 1;
		
		for(int k=0; k<sCo.length; k++)
			sCo[k] = Co[k] == recCo[k] ? 0 : 1;
		sPo = Po == recPo ? 0 : 1;
		
		sCiq = (sCi[0]==1 || sCi[1]==1 || sCi[2]==1 ) ? 1 : 0;
		sCoq = (sCo[0]==1 || sCo[1]==1 || sCo[2]==1 ) ? 1 : 0;
	}
	public void computeErrorAddress() {	// Compute outer and inner error address
		EArO = sCo[2] * 4 + sCo[1] * 2 + sCo[0];
		EArI = sCi[2] * 4 + sCi[1] * 2 + sCi[0];
	}
	public void computeSE_DE() {	// Compute single and double error
		SErI = sCiq==1 && sPi==1;
		DErI = sCiq==1 && sPi==0;
		SErO = sCoq==1 && sPo==1;
		DErO = sCoq==1 && sPo==0;
	}
	private void setErrorPattern(int errorPattern[]) throws Exception {
		for(int k = 0; k < errorPattern.length; k++)
			setError(errorPattern[k]);
	}
	private static int invertBit(int value) {
		return value == 0 ? 1 : 0;
	}
	private void setError(int errorPosition) throws Exception {
		if(errorPosition < 4)
			D[errorPosition] = invertBit(D[errorPosition]);
		else if(errorPosition >= 4 && errorPosition < 7) {
			errorPosition -= 4;
			Co[errorPosition] = invertBit(Co[errorPosition]);
		}
		else if(errorPosition == 7) {
			Po = invertBit(Po);
		}
		else if(errorPosition >= 8 && errorPosition < 11) {
			errorPosition -= 8;
			Ci[errorPosition] = invertBit(Co[errorPosition]);
		}
		else if(errorPosition == 11) {
			Pi = invertBit(Pi);
		}
		else
			throw new Exception("Error position = " + errorPosition);
	}
	public String toString() {
		String str = "D [0 1]   [0 1 2] [P]   [0 1 2]  [sCq][sP][DE][SE][Add]\n";
		
		int de = DErO == true ? 1 : 0;
		int se = SErO == true ? 1 : 0;
		int di = DErI == true ? 1 : 0;
		int si = SErI == true ? 1 : 0;
		str = str+" 0["+D[0]+" "+D[1]+" ]Ce["+Co[0]+" "+Co[1]+" "+Co[2]+" ]["+Po+
				"]sCe["+sCo[0]+" "+sCo[1]+" "+sCo[2]+" ]  ["+sCoq+"] ["+sPo+"] ["+de+"] ["+se+"] ["+EArO+"]\n";
		str = str+" 1["+D[2]+" "+D[3]+" ]Ci["+Ci[0]+" "+Ci[1]+" "+Ci[2]+" ]["+Pi+
				"]sCi["+sCi[0]+" "+sCi[1]+" "+sCi[2]+" ]  ["+sCiq+"] ["+sPi+"] ["+di+"] ["+si+"] ["+EArI+"]\n";
				
		return str;
	}
}

