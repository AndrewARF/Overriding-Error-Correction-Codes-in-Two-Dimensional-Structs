public class CodeStruct {
	public int D[] = new int[4];	// Data array
	public int Co[] = new int[3];	// Outer check-bit array
	public int Ci[] = new int[3];	// Inner check-bit array
	public int Po, Pi; 				// Outer and Inner parity bits
	// Receive data array, codify in Hamming and parity for the Outer and Inner ECCs
	public CodeStruct(int D[]) throws Exception {
		for(int r=0; r<this.D.length; r++)
			this.D[r] = D[r];
		encodeOuterHamming(Co);
		Po = encodeHammingParity(Co);
		encodeInnerHamming(Ci);
		Pi = encodeHammingParity(Ci);
	}
	protected void encodeInnerHamming(int ham[]) { // Codify Inner Hamming
		ham[0]	= D[0] ^ D[1] ^ D[2]; //7 3 5
		ham[1]	= D[0] ^ D[1] ^ D[3]; // 7 3 6
		ham[2]	= D[0] ^ D[2] ^ D[3]; // 7 5 6
	}
	protected void encodeOuterHamming(int ham[]) { // Codify Outer Hamming
		ham[0] = D[0] ^ D[1] ^ D[3]; // 3 5 7 
		ham[1] = D[0] ^ D[2] ^ D[3]; // 3 6 7
		ham[2] = D[1] ^ D[2] ^ D[3]; // 5 6 7
	}
	protected int encodeHammingParity(int ham[]) { // Codify Inner and Outer Parity
		int parity = ham[0];
		
		for(int k=1; k<ham.length; k++)
			parity =  parity ^ ham[k];
		for(int j=0; j<this.D.length; j++) {
			parity = parity ^ D[j];
		}
		return parity;
	}
	public boolean isEqual(CodeStruct ecc) { // Compare data array of two instances of Codestruct
		for(int k=0; k<D.length; k++) {
			if(D[k] != ecc.D[k])
				return false;
		}
		return true;
	}
	public String toString() {
		String str = "";
		str = str + "[" + D[0] + " " + D[1] + " ][" + Co[0] + " " + Co[1] + " " + Co[2] + " ][" + Po + "]\n";
		str = str + "[" + D[2] + " " + D[3] + " ][" + Ci[0] + " " + Ci[1] + " " + Ci[2] + " ][" + Pi + "]\n";
		return str;
	}
}
