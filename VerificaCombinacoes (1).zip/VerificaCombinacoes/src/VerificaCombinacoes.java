import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class VerificaCombinacoes 
{
//	Externo:                     30, 25, 27, 15, 10, 18, 11, 6, 17, 19, 9, 12, 24, 13, 21, 14, 
//	Interno:                      11, 20, 5, 12, 10, 23, 28, 31, 29, 21, 3, 17, 27, 26, 25, 30, FIM
//	public static int vetExt[] = {3, 7, 23, 14, 19, 11, 24, 9, 26, 15, 13, 17, 29, 5, 25, 12}; 
//	public static int vetInt[] = {6, 12, 31, 27, 13, 30, 5, 29, 9, 25, 19, 28, 23, 10, 3, 18}; 
	public static int vetExt[] = new int[16];
	public static int vetInt[] = new int[16];
	public static int possibilidades[] = {3,5,6,7,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
	public static List<Pair> pairsList = new ArrayList<>();
	
	public static int tab[][] =
	{
		{6, 5, 4, 10, 9, 8, 15, 14, 13, 12, 18, 17, 16, 23, 22, 21, 20, 27, 26, 25, 24, 31, 30, 29, 28},
		{3, 2, 12, 15, 14, 9, 8, 11, 10, 20, 23, 22, 17, 16, 19, 18, 29, 28, 31, 30, 25, 24, 27, 26},
		{1, 15, 12, 13, 10, 11, 8, 9, 23, 20, 21, 18, 19, 16, 17, 30, 31, 28, 29, 26, 27, 24, 25},
		{14, 13, 12, 11, 10, 9, 8, 22, 21, 20, 19, 18, 17, 16, 31, 30, 29, 28, 27, 26, 25, 24},
		{3, 2, 5, 4, 7, 6, 24, 27, 26, 29, 28, 31, 30, 17, 16, 19, 18, 21, 20, 23, 22},
		{1, 6, 7, 4, 5, 27, 24, 25, 30, 31, 28, 29, 18, 19, 16, 17, 22, 23, 20, 21},
		{7, 6, 5, 4, 26, 25, 24, 31, 30, 29, 28, 19, 18, 17, 16, 23, 22, 21, 20},
		{1, 2, 3, 29, 30, 31, 24, 25, 26, 27, 20, 21, 22, 23, 16, 17, 18, 19},
		{3, 2, 28, 31, 30, 25, 24, 27, 26, 21, 20, 23, 22, 17, 16, 19, 18},
		{1, 31, 28, 29, 26, 27, 24, 25, 22, 23, 20, 21, 18, 19, 16, 17},
		{30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16},
		{3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14},
		{1, 6, 7, 4, 5, 10, 11, 8, 9, 14, 15, 12, 13},
		{7, 6, 5, 4, 11, 10, 9, 8, 15, 14, 13, 12},
		{1, 2, 3, 12, 13, 14, 15, 8, 9, 10, 11},
		{3, 2, 13, 12, 15, 14, 9, 8, 11, 10},
		{1, 14, 15, 12, 13, 10, 11, 8, 9},
		{15, 14, 13, 12, 11, 10, 9, 8},
		{1, 2, 3, 4, 5, 6, 7},
		{3, 2, 5, 4, 7, 6},
		{1, 6, 7, 4, 5},
		{7, 6, 5, 4},
		{1, 2, 3},
		{3, 2},
		{1},
	};
	
	public static void main(String[] args) throws Exception
	{
		int tentativas = 1;
		while(true)
		{
			if(executa() == true)
				break;
			tentativas++;
			pairsList.clear();
			System.out.print(tentativas + ", ");
		}
		System.out.println(pairsList);
		System.out.print("\nExterno: ");
		for(int k=0; k<vetExt.length; k++)
			System.out.print(vetExt[k] + ", ");
		System.out.print("\nInterno: ");
		for(int k=0; k<vetInt.length; k++)
			System.out.print(vetInt[k] + ", ");
		System.out.print("FIM");
	}
	private static boolean executa() throws Exception
	{
		int possibilidadesAux[] = new int[possibilidades.length];
		for(int k=0; k<possibilidadesAux.length; k++)
			possibilidadesAux[k] = possibilidades[k];
		Random random = new Random();
		int limite = possibilidadesAux.length -1;
		for(int k=0; k<vetExt.length; k++) {
			int posicao = random.nextInt(limite);
			vetExt[k] = possibilidadesAux[posicao];
			possibilidadesAux[posicao] = possibilidadesAux[limite];
			limite--;
		}
		for(int k=0; k<possibilidadesAux.length; k++)
			possibilidadesAux[k] = possibilidades[k];
		limite = possibilidadesAux.length -1;
		for(int k=0; k<vetInt.length; k++) {
			int posicao = random.nextInt(limite);
			vetInt[k] = possibilidadesAux[posicao];
			possibilidadesAux[posicao] = possibilidadesAux[limite];
			limite--;
		}
		try 
		{
			errorGenerator(0, new int[2], 0);
		} 
		catch(Exception e)
		{
			return false;
		}
		return true;
	}
	private static void errorGenerator(int errorIndex, int errorPattern[], int elementIndex) throws Exception 
	{ 
		if(errorIndex == 2) 
		{ 
			int externo = combinacao(vetExt[errorPattern[0]], vetExt[errorPattern[1]]);
			int interno = combinacao(vetInt[errorPattern[0]], vetInt[errorPattern[1]]);
			
			System.out.println(	externo + "_" + interno + "[" + vetExt[errorPattern[0]] + ", " + vetExt[errorPattern[1]] + "][" + vetInt[errorPattern[0]] + ", " + vetInt[errorPattern[1]]+ "]");
            Pair pair = new Pair(externo, interno);
            if(pairsList.contains(pair))
            	throw new Exception();
            pairsList.add(pair);
			return; 
		} 
		if(elementIndex >= 16) 
			return;
		errorPattern[errorIndex] = elementIndex; 
		errorGenerator(errorIndex+1, errorPattern, elementIndex+1); 
		errorGenerator(errorIndex, errorPattern, elementIndex+1); 
	}
	private static int combinacao(int x, int y) {
		if(x>y) {
			int z = x;
			x = y;
			y = z;
		}
		if(x>16)
			x--;
		if(x>8)
			x--;
		if(x>4)
			x--;
		x = x - 3;
		if(y>16)
			y--;
		if(y>8)
			y--;
		y = y - 5;
		y = y - x;
		return tab[x][y];
	}
}

class Pair 
{
    private int first;
    private int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }

    public int getFirst() {
        return first;
    }

    public int getSecond() {
        return second;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Pair pair = (Pair) o;

        if (first == pair.first && second == pair.second) return true;
        return first == pair.second && second == pair.first;
    }

    @Override
    public int hashCode() {
        int result = first;
        result = 31 * result + second;
        return result;
    }
    public String toString() {
    	return "[" + first + " " + second + "]";
    }
}


