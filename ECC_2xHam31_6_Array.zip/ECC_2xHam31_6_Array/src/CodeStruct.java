public class CodeStruct {
	public int D[] = new int[16];	// Data array
	public int Co[] = new int[5];	// Outer check-bit array
	public int Ci[] = new int[5];	// Inner check-bit array
	public int Po, Pi; 				// Outer and Inner parity bits
	// Receive data array, codify in Hamming and parity for the Outer and Inner ECCs
	public CodeStruct(int D[]) throws Exception {
		for(int r=0; r<this.D.length; r++)
			this.D[r] = D[r];
		encodeOuterHamming(Co);
		Po = encodeHammingParity(Co);
		encodeInnerHamming(Ci);
		Pi = encodeHammingParity(Ci);
	}
	protected void encodeOuterHamming(int ham[]) { // Codify Outer Hamming
		ham[0] = D[11] ^ D[4]  ^ D[2]  ^ D[6]  ^ D[14] ^ D[8]  ^ D[12]; 	
		ham[1] = D[7]  ^ D[5]  ^ D[15] ^ D[10] ^ D[3]  ^ D[9]  ^ D[6] ^ D[14] ^ D[8] ^ D[12];
		ham[2] = D[13] ^ D[1]  ^ D[15] ^ D[10] ^ D[3]  ^ D[9]  ^ D[2] ^ D[12];
		ham[3] = D[0]  ^ D[1]  ^ D[5]  ^ D[3]  ^ D[9]  ^ D[4]  ^ D[2] ^ D[8];
		ham[4] = D[0]  ^ D[13] ^ D[1]  ^ D[7]  ^ D[5]  ^ D[10] ^ D[9] ^ D[11] ^ D[4] ^ D[2] ^ D[14] ^ D[12];
	}
	protected void encodeInnerHamming(int ham[]) { // Codify Inner Hamming
		ham[0]	= D[15] ^ D[10] ^ D[12] ^ D[9]  ^ D[3]  ^ D[11] ^ D[7]  ^ D[5] ^ D[2];
		ham[1]	= D[8]  ^ D[13] ^ D[1]  ^ D[4]  ^ D[9]  ^ D[3]  ^ D[11] ^ D[7] ^ D[5] ^ D[2];
		ham[2]	= D[6]  ^ D[0]  ^ D[1]  ^ D[4]  ^ D[12] ^ D[11] ^ D[7]  ^ D[5] ^ D[2];
		ham[3]	= D[14] ^ D[0]  ^ D[13] ^ D[15] ^ D[10] ^ D[12] ^ D[3]  ^ D[5] ^ D[2];
		ham[4]	= D[14] ^ D[6]  ^ D[8]  ^ D[4]  ^ D[10] ^ D[12] ^ D[9]  ^ D[3] ^ D[7] ^ D[2];
	}
	protected int encodeHammingParity(int ham[]) { // Codify Inner and Outer Parity
		int parity = ham[0];
		
		for(int k=1; k<ham.length; k++)
			parity =  parity ^ ham[k];
		for(int j=0; j<this.D.length; j++) {
			parity = parity ^ D[j];
		}
		return parity;
	}
	public boolean isEqual(CodeStruct ecc) { // Compare data array of two instances of Codestruct
		for(int k=0; k<D.length; k++) {
			if(D[k] != ecc.D[k])
				return false;
		}
		return true;
	}
	public String toString() {
		String str = "";
		str = str + "[" + D[0]  + " " + D[1]  + " " + D[2]  + " " + D[3]  + "][" + Co[0] + " " + Co[1] + " " + Co[2] + " " + Co[3] + " " + Co[4] + "][" + Po + "]\n";
		str = str + "[" + D[4]  + " " + D[5]  + " " + D[6]  + " " + D[7]  + "][" + Ci[0] + " " + Ci[1] + " " + Ci[2] + " " + Ci[3] + " " + Ci[4] + "][" + Pi + "]\n";
		str = str + "[" + D[8]  + " " + D[9]  + " " + D[10] + " " + D[11] + "]\n";
		str = str + "[" + D[12] + " " + D[13] + " " + D[14] + " " + D[15] + "]\n";
		return str;
	}
}

/* Data and check-bit organizations of Outer Hamming coding
D0	D1	D2	D3	Ce0	Ce1	Ce2	Ce3	Ce4	
D4	D5	D6	D7						
D8	D9	D10	D11						
D12	D13	D14	D15						
									
Numbering of Outer Hamming									
3	7	23	14	16	8	4	2	1	
19	11	24	9						
26	15	13	17						
29	5	25	12						
									
Outer parity encoding									
D0	D1	D2	D3	D20	D21	D22	D23	D24	Po  
D4	D5	D6	D7						
D8	D9	D10	D11						
D12	D13	D14	D15						

Data and check-bit organizations of Inner Hamming coding									
D0	D1	D2	D3						
D4	D5	D6	D7	Ci0	Ci1	Ci2	Ci3	Ci4	
D8	D9	D10	D11						
D12	D13	D14	D15						
									
Numbering of Inner Hamming										
6	12	31	27	16	8	4	2	1	
13	30	5	29						
9	25	19	28						
23	10	3	18						
									
Inner parity encoding								
D15	D14	D13	D12						
D11	D10	D9	D8	D20	D21	D22	D23	D24	Pi  
D7	D6	D5	D4						
D3	D2	D1	D0						

Binary	Dec	Bit		Inner Hamming composition		Outer Hamming composition				
00001	1	C4		Ci0	Ci1	Ci2	Ci3	Ci4				Ce0	Ce1	Ce2	Ce3	Ce4
00010	2	C3												
00011	3	D0					D14	D14							D0	D0
00100	4	C2												
00101	5	D1				D6		D6						D13		D13
00110	6	D2				D0	D0							
00111	7	D3												D1	D1	D1
01000	8	C1												
01001	9	D4			D8			D8					D7			D7
01010	10	D5			D13		D13							
01011	11	D6											D5		D5	D5
01100	12	D7			D1	D1							D15	D15		
01101	13	D8			D4	D4		D4					D10	D10		D10
01110	14	D9											D3	D3	D3	
01111	15	D10											D9	D9	D9	D9
10000	16	C0												
10001	17	D11										D11				D11
10010	18	D12		D15			D15							
10011	19	D13		D10			D10	D10				D4			D4	D4
10100	20	D14												
10101	21	D15												
10110	22	D16												
10111	23	D17		D12		D12	D12	D12				D2		D2	D2	D2
11000	24	D18										D6	D6			
11001	25	D19		D9	D9			D9				D14	D14			D14
11010	26	D20										D8	D8		D8	
11011	27	D21		D3	D3		D3	D3						
11100	28	D22		D11	D11	D11								
11101	29	D23		D7	D7	D7		D7				D12	D12	D12		D12
11110	30	D24		D5	D5	D5	D5							
11111	31	D25		D2	D2	D2	D2	D2						

Value	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31
All		C4	C3	D0	C2	D1	D2	D3	C1	D4	D5	D6	D7	D8	D9	D10	C0	D11	D12	D13	D14	D15	D16	D17	D18	D19	D20	D21	D22	D23	D24	D25
Outer	Ce4	Ce3	D0	Ce2	D13		D1	Ce1	D7		D5	D15	D10	D3	D9	Ce0	D11		D4				D2	D6	D14	D8			D12		
Inner	Ci4	Ci3	D14	Ci2	D6	D0		Ci1	D8	D13		D1	D4			Ci0		D15	D10				D12		D9		D3	D11	D7	D5	D2

 */

