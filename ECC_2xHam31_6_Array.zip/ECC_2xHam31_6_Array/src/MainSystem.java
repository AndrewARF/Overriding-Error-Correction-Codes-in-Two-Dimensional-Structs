public class MainSystem {
	public static final boolean DEBUG = false;	// Set true for debugging purposes
	
	private static int numErrors, initialElement = 0, numElements = 28;
	private static long numberOfDecodigns = 0, errorsAfterDecoding = 0;
	private static CodeStruct initialCodeStruct;
	private static CodeStructWithErrror eccWithErrors;

	private static void errorGenerator(int errorIndex, int errorPattern[], int elementIndex) throws Exception 
	{ 
		if(errorIndex == numErrors) 
		{ 
			eccWithErrors = new CodeStructWithErrror(initialCodeStruct, errorPattern);
			if(DEBUG){
				System.out.print(eccWithErrors);
			}
			Decoder.decoding(eccWithErrors);
			numberOfDecodigns++;
			
			if(!initialCodeStruct.isEqual(eccWithErrors)) {
				errorsAfterDecoding++;
				if(DEBUG){
					System.out.println(eccWithErrors);
					System.out.println("==> ERRO!\n");
				}
			}
			return; 
		} 
		if(elementIndex >= numElements) 
			return;
		errorPattern[errorIndex] = elementIndex; 
		errorGenerator(errorIndex+1, errorPattern, elementIndex+1); 
		errorGenerator(errorIndex, errorPattern, elementIndex+1); 
	}
	private static void setInitialCodeStruct() throws Exception {
		int D[] = {	0, 0, 0, 0, 
					0, 0, 0, 0,
					0, 0, 0, 0,
					0, 0, 0, 0, };
		initialCodeStruct = new CodeStruct(D);
	}
	private static void printTestIdentification() {
		System.out.println("#Errors=" + numErrors);
	}
	private static void printResults() {
	    System.out.println("\n\tNumberOfDecodigns = " + numberOfDecodigns);
	    System.out.println("\tNumberOfErrorsAfterDecoding = " + errorsAfterDecoding);
	}
	private static void setNumberOfErrors(int nE) {
		numErrors = nE;
	}
	private static void resetSimulationData() {
		numberOfDecodigns = 0;
		errorsAfterDecoding = 0;
	}
	private static void setErrorInterval(int inicio, int fim) {
		initialElement = inicio;
		numElements = fim;
	}
	public static void main(String[] args) throws Exception {
		long startTime = System.nanoTime();
		setInitialCodeStruct();
		setErrorInterval(0, 28);  // Default is (0, 28) ==> All bits
 		for(int numberOfErrors=0; numberOfErrors<=5; numberOfErrors++)
		{
			setNumberOfErrors(numberOfErrors);
			printTestIdentification();
			resetSimulationData();
			errorGenerator(0, new int[numErrors], initialElement);
			printResults();
		}
		long endTime = System.nanoTime();
		long duration = endTime - startTime;
		System.out.println("Duration: " + duration + " ns");
	}
}