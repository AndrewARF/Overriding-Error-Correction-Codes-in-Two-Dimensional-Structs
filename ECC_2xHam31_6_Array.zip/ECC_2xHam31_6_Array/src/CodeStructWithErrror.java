public class CodeStructWithErrror extends CodeStruct
{
	public int recCo[] = new int[5];	// Array storing the computation of the Outer Hamming in the decoding process 
	public int recCi[] = new int[5];	// Array storing the computation of the Inner Hamming in the decoding process 
	public int recPo, recPi;			// Bits storing the Outer and Inner parities computed in the decoding process 
	
	public int sCo[] = new int[5];		// Array of Outer Hamming syndromes
	public int sCi[] = new int[5];		// Array of Inner Hamming syndromes
	public int sPo, sPi;				// Outer and Inner parity syndromes
	public int sCoq, sCiq;				// Bits enclosing the OR of all bits of the Outer and Inner syndrome arrays

	public int EArO, EArI;				// Outer and Inner error addresses
	public boolean DErO, SErO;			// Flags of double and single error on Outer ECC
	public boolean DErI, SErI;			// Flags of double and single error on Inner ECC
	public CodeStructWithErrror(CodeStruct initialCodeStruct, int errorPattern[]) throws Exception { // Constructor for creating an instance of the code with an error pattern inserted
		super(initialCodeStruct.D);
		setErrorPattern(errorPattern);
		recomputeControlVariables();
	}
	public void recomputeControlVariables() { // Method that recompute all control variables after correcting an error
		recomputeCheckBitsAndParity();
		computeSyndromes();
		computeErrorAddress();
		computeSE_DE();
	}
	public void recomputeCheckBitsAndParity() { // Recompute Hamming and parity of Outer and Inner ECCs
		encodeOuterHamming(recCo);
		recPo = encodeHammingParity(Co);
		encodeInnerHamming(recCi);
		recPi = encodeHammingParity(Ci);
	}
	public void computeSyndromes() { // Compute all syndromes
		for(int k=0; k<sCi.length; k++)
			sCi[k] = Ci[k] == recCi[k] ? 0 : 1;
		sPi = Pi == recPi ? 0 : 1;
		
		for(int k=0; k<sCo.length; k++)
			sCo[k] = Co[k] == recCo[k] ? 0 : 1;
		sPo = Po == recPo ? 0 : 1;
		
		sCiq = (sCi[0]==1 || sCi[1]==1 || sCi[2]==1 || sCi[3]==1 || sCi[4]==1) ? 1 : 0;
		sCoq = (sCo[0]==1 || sCo[1]==1 || sCo[2]==1 || sCo[3]==1 || sCo[4]==1) ? 1 : 0;
	}
	public void computeErrorAddress() {	// Compute outer and inner error address
		EArO = sCo[0] * 16 + sCo[1] * 8 + sCo[2] * 4 + sCo[3] * 2 + sCo[4];
		EArI = sCi[0] * 16 + sCi[1] * 8 + sCi[2] * 4 + sCi[3] * 2 + sCi[4];
	}
	public void computeSE_DE() {	// Compute single and double error
		SErI = sCiq==1 && sPi==1;
		DErI = sCiq==1 && sPi==0;
		SErO = sCoq==1 && sPo==1;
		DErO = sCoq==1 && sPo==0;
	}
	private void setErrorPattern(int errorPattern[]) throws Exception {
		for(int k = 0; k < errorPattern.length; k++)
			setError(errorPattern[k]);
	}
	private static int invertBit(int value) {
		return value == 0 ? 1 : 0;
	}
	private void setError(int errorPosition) throws Exception {
		if(errorPosition < 16)
			D[errorPosition] = invertBit(D[errorPosition]);
		else if(errorPosition >= 16 && errorPosition < 21) {
			errorPosition -= 16;
			Co[errorPosition] = invertBit(Co[errorPosition]);
		}
		else if(errorPosition == 21) {
			Po = invertBit(Po);
		}
		else if(errorPosition >= 22 && errorPosition < 27) {
			errorPosition -= 22;
			Ci[errorPosition] = invertBit(Co[errorPosition]);
		}
		else if(errorPosition == 27) {
			Pi = invertBit(Pi);
		}
		else
			throw new Exception("Error position = " + errorPosition);
	}
	public String toString() {
		String str = "D [0 1 2 3]  [0 1 2 3 4][P]   [0 1 2 3 4][sCq][sP][DE][SE][Add]\n";
		
		int de = DErO == true ? 1 : 0;
		int se = SErO == true ? 1 : 0;
		int di = DErI == true ? 1 : 0;
		int si = SErI == true ? 1 : 0;
		str = str+" 0["+D[0] +" "+D[1] +" "+D[2] +" "+D[3] +"]Ce["+Co[0]+" "+Co[1]+" "+Co[2]+" "+Co[3]+" "+Co[4]+"]["+Po+"]sCe["+sCo[0]+" "+sCo[1]+" "+sCo[2]+" "+sCo[3]+" "+sCo[4]+"]  ["+sCoq+"] ["+sPo+"] ["+de+"] ["+se+"]["+EArO+"]\n";
		str = str+" 1["+D[4] +" "+D[5] +" "+D[6] +" "+D[7] +"]Ci["+Ci[0]+" "+Ci[1]+" "+Ci[2]+" "+Ci[3]+" "+Ci[4]+"]["+Pi+"]sCi["+sCi[0]+" "+sCi[1]+" "+sCi[2]+" "+sCi[3]+" "+sCi[4]+"]  ["+sCiq+"] ["+sPi+"] ["+di+"] ["+si+"]["+EArI+"]\n";
		str = str+" 2["+D[8] +" "+D[9] +" "+D[10]+" "+D[11]+"]\n";
		str = str+" 3["+D[12]+" "+D[13]+" "+D[14]+" "+D[15]+"]\n";
		
		return str;
	}
}

